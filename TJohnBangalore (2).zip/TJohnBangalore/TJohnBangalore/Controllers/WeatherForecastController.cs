﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using TJohnBangalore.Logs;

namespace TJohnBangalore.Controllers
{



    [Authorize]
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {

       
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILoggerManager _logger;
        private readonly IJWTManagerRepository _ijwt;

        public WeatherForecastController(ILoggerManager logger,IJWTManagerRepository jwt)
        {
            _logger = logger;
            _ijwt = jwt;
        }


        [Authorize(Roles = "User")]
        [HttpPut]
        [Route("demo")]
        public IActionResult Demo()
        {
           // return Ok("All well");
            return Redirect("demoone");
        }


        [HttpGet]
        [Route("demoone")]
        public string Redirect()
        {
            return "Redirected";
        }

        [HttpGet]
        public string Get()
        {
            var identity = HttpContext.User;
            // var users = new List<string>
            //{
            //    "Satinder Singh",
            //    "Amit Sarna",
            //    "Davin Jon",
            //    claims.FindFirst("Name").Value
            //};

            
            string users = identity.Claims.First(x => x.Type == "Name").Value;
            return users;
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("authenticate")]
        public IActionResult Authenticate(Users user)
        {
            _logger.LogError("POST Authenticate Error");
            _logger.LogDebug("POST Authenticate Debug");
            _logger.LogInfo("POST Authenticate Info");
            _logger.LogWarning("POST Authenticate Warning");

            _logger.LogError("POST Authenticate Error");
            _logger.LogDebug("POST Authenticate Debug");
            _logger.LogInfo("POST Authenticate Info");
            _logger.LogWarning("POST Authenticate Warning");

            // _logger.LogError("POST Authenticate");
            var token = _ijwt.Authenticate(user);
            if (token == null)
            {
                return Unauthorized();
            }

            return Ok(token);
        }

        //[HttpGet]
        //public IEnumerable<WeatherForecast> Get()
        //{
        //    var rng = new Random();
        //    return Enumerable.Range(1, 5).Select(index => new WeatherForecast
        //    {
        //        Date = DateTime.Now.AddDays(index),
        //        TemperatureC = rng.Next(-20, 55),
        //        Summary = Summaries[rng.Next(Summaries.Length)]
        //    })
        //    .ToArray();
        //}
    }
}
